THE CHARLES FAMILY - BABY SHOWER WEBSITE

FILES
  index.html                  the invitation (all settings are in "eventDetails" near the bottom)
  og.png                      the picture shown when the link is shared in texts/social
  netlify/functions/count.mjs the shared guest counter (anonymous)

PUBLISH FREE ON NETLIFY (about 5 minutes)
  1. Make a free account at github.com and create a new repository. Upload every file in this folder (keep the folders).
  2. Make a free account at netlify.com > Add new site > Import an existing project > pick that repository > Deploy.
  3. Netlify gives you a link like yourname.netlify.app. Open it on your phone and tap COUNT ME IN to test.
  4. Optional: Site settings > Domain management to choose a nicer name.
  5. In index.html change  content="/og.png"  to  content="https://YOUR-LINK/og.png"  so link previews show the picture.

TO CHANGE THINGS LATER
  Open index.html and edit eventDetails (registry link, venueConfirmed, time, etc.), then commit - Netlify republishes automatically.
