import { getStore } from "@netlify/blobs";

// Anonymous shared guest counter. Stores only a total and random anonymous tokens
// (used to stop the same device counting twice). No names or contact info.
export default async (req) => {
  const store = getStore("guests");
  const data = (await store.get("tally", { type: "json" })) || { count: 0, tokens: [] };
  if (req.method === "POST") {
    let token = "";
    try { token = String((await req.json()).token || "").slice(0, 80); } catch {}
    if (token && !data.tokens.includes(token)) {
      data.tokens.push(token);
      data.count = data.tokens.length;
      await store.setJSON("tally", data);
    }
  }
  return new Response(JSON.stringify({ count: data.count }), {
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
};

export const config = { path: "/api/count" };
